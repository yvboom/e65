---------------------------------------------------------------------------
-----------------------------------------------------------------------------

*** Life beyond 65: Changing spatial patterns of survival at older ages in 
the United States, 2000-2016 ***

The Journal of Gerontology: Social Science
Vierboom & Preston 2020

This Readme file outlines all of the do-files. For more detail (more complex
do-files have a "Table of Contents"), please see the do-files themselves.

-----------------------------------------------------------------------------
-----------------------------------------------------------------------------


*** MASTER.do ***

Aim: This do-file reproduces all of the results in the analysis. It is a 
master do-file that runs all of the other do-files. 

Input: All of the files created by the other do-files.

Output: All figures and tables in the paper (stored in results).


----------------


*** Fig1.do ***

Aim: This do-file produces Figure 1 (graphs of life expectancy at age 65 by 
region and metro categories, in two panels).

Input:
-"Life Tables by Metro 4-Category by Sex.csv" (formatted data)
-"Life Tables by Region by Sex.csv" (formatted data)

Output: 
-Fig1.svg (results)


----------------


*** Fig2.do ***

Aim: This do-file produces Figure 2 (scatterplot of e65 in 2000 vs e65 in 
2016 for the 40 spatial units, side-by-side for sex.).

Input: 
-"Life Tables by Metro 4-Category by Sex.csv" (formatted data)

Output:
-Fig2.svg (results) 


----------------


*** Table1_&_AppTable3.do ***

Aim: This do-file produces Table 1, listing all 40 units e65 in 2000 and 2016,
as well as overall values for region and metro. It also produces Appendix 
Table 3 (supplmental Excel spreadsheet) with annual values from 2000-2016.
 
Input: 
-"Life Tables by Metro 4-Category and Region by Sex.csv" (formatted data)
-"Life Tables by Metro 4-Category by Sex.csv" (formatted data)
-"Life Tables by Region by Sex.csv" (formatted data)
-"hmd" (formatted data)

Output: 
-AppTable3.xlsx (results)
-Table1.xlsx (results)


----------------


*** Table2.do ***

Aim: This do-file produces Table 2, which regresses the change in e65 
2000-2016 on region and metro status, and then uses the margins to predict 
change in each unit type, while holding the other status constant.

Input: 
-"Life Tables by Metro 4-Category and Region by Sex.csv" (formatted data)

Output: 
-Table2.xlsx (results)

----------------


*** Table3.do ***

Aim: This do-file decomposes period changes in life expectancy at birth into 
cause-specific contributions, by ages--across region and metro categories.

Input: 
-"Life Tables by Metro 4-Category and Region by Sex.csv" (formatted data)
-"Life Tables by Metro 4-Category by Sex.csv" (formatted data)
-"Life Tables by Region by Sex.csv" (formatted data)
-"proportions_metro.dta" (formatted data)
-"proportions_region.dta" (formatted data)

Output: 
-Table3.xlsx (results)


----------------


*** AppTable4.do ***

Aim: This do-file reproduces the results of Appendix Table 4. The appendix
regresses cause-specific contributions on region and metro status to estimate 
the percentage of variation in e65 levels and change among the 40 units 
associated with region vs metro status.

Input: 
-"Life Tables by Metro 4-Category and Region by Sex.csv" (formatted data)

Output: 
-AppTable3.xlsx (results)


----------------


*** AppTable5.do ***

Aim: This do-file reproduces the results of Appendix Table 5. The appendix 
ranks e65 in 2016 and changes therein between 2000-2016 in several OECD 
countries, including the US. The table also ranks the best- and 
worst-performing US spatial unit (of the 40) as if they were countries.

The do-file merges the US life tables with data from the Human Mortality 
database (created by the "hmd" dofile).

Input: 
-"Life Tables by Metro 4-Category and Region by Sex.csv" (formatted data)
-"hmd" (formatted data)

Output: 
-AppTable5.xlsx


----------------


*** hmd.do (NOTE: THIS DO-FILE SHOULD NOT BE RUN FOR THE REPLICATION) ***

Aim: This do-file formats data from the Human Mortality Database into a dataset
with data on e65 in 2000 and 2016 for OECD countries (incl. US) with data in 
2016 on at least a population of 5 million people. The resultig dataset is 
used by a different do-file to create Appendix Table 5. Data from 1990 for 
the US only is also used in Appendix Table 3.

The data was downloaded using the server at the Max Planck Institute for Demographic 
Research. Although the link to the server won't work outside the Institute, a 
user could download the data from the HMD website and run the code below. 
To make things easier, the replication files include the already-formatted HMD
dataset, so there is no need to run this do-file. The code is given for the sake
of completeness.

Output: 
-hmd.dta


----------------


*** CODproportions,do (NOTE: THIS DO-FILE SHOULD NOT BE RUN FOR THE REPLICATION) ***

Aim: The input data for this do-file (annual multiple cause-of-death files) is
not publicly-available without a user agreement. The dataset created from the
annual data (proportions of all deaths due to specific causes) is saved in the
"formatted_data" subfolder. It is used for the decomposition in Table 3.

Output: 
-proportion_metro.dta (formatted data)
-proportions_region.dta (formatted data)


----------------