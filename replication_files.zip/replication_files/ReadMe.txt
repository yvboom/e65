---------------------------------------------------------------------------
-----------------------------------------------------------------------------

*** Life beyond 65: Changing spatial patterns of survival at older ages in 
the United States, 2000-2016 ***

The Journal of Gerontology: Social Science
Vierboom & Preston 2020

-----------------------------------------------------------------------------
-----------------------------------------------------------------------------

A brief description of the sub-folders in this folder:

dofiles: This folder contains the do-file that run all elements of the 
analysis. A ReadMe file describes these dofiles in detail.

formatted_data: This folder contains data formatted by the dofiles
contained in the dofiles folder. These formatted datasets are not results,
but rather intermediary datasets that are needed to perform some of
the analyses.

logfiles: Each dofile produces a logfile of the same name that contains a
record of the analysis.

results: This folder contains the results of all analyses, often in Excel
table format. Results are labeled according to their location in the paper
(ex: Table 3, AppTable2, etc.). While the Tables then need just a little
more formatting in Excel or Word (like making columns wider), the actual
results are all there and, for the most part, formatted correctly.

-----------------------------------------------------------------------------
-----------------------------------------------------------------------------
